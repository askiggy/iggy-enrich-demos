## Iggy Benchmark Dataset: SFH Sales in Pinellas County, FL 

Last updated: 01 November, 2021
Author: Ask Iggy, Inc.

### Summary

This dataset contains details of 38,388 single family home sales in Pinellas County, FL, between 2019 and 2021. 

The original data was retrieved from the office of the [Pinellas County Property Assessor](https://www.pcpao.org/).

### Important fields

The `strap` field is a unique identifier for each property.

The `split` column denotes the dataset split, which was performed randomly (60% train, 20% validation, 20% test).

All other columns describe properties of each sold home. Categorical features (`current_tax_district_dscr_*`, `frontage_*`, `views_*`, `description_*`, `exterior_wall_*`, `roof_frame_*`, `roof_cover_*`, `foundation_*`, `floor_system_*`, `floor_finish_*`, `cooling_*`, `sale_day_of_week_*`, `sale_day_*`, `sale_month_*`, `sale_year_*`, `sale_quarter_*`, `heating_*`, `interior_finish_*`, `quality_*`) have been encoded as one-hot.

### Attribution

This dataset is distributed under the Creative Commons Attribution 4.0 International Public License. You are free to share and adapt this dataset under the terms of the license as long as you provide attribution to the dataset author, Ask Iggy, Inc. (https://www.askiggy.com/).

